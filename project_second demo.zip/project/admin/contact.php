<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DB connection
$conn = new mysqli("localhost", "root", "", "onlinefoodphp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = "";
$email = "";

// Get user data if logged in
if (isset($_SESSION["user_id"])) {
    $user_id = $_SESSION["user_id"];
    $result = $conn->query("SELECT username, email FROM register WHERE u_id = '$user_id' LIMIT 1");
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $name = $user['username'];
        $email = $user['email'];
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION["user_id"])) {
        echo "<script>alert('Please login first to submit the form.'); window.location.href='login.php';</script>";
        exit;
    }

    // Sanitize input
    $message = $conn->real_escape_string($_POST['message']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);

    // Insert
    $sql = "INSERT INTO contact (name, email, message) VALUES ('$name', '$email', '$message')";
    if ($conn->query($sql)) {
        echo "<script>alert('Message submitted successfully!'); window.location.href=window.location.href;</script>";
        exit;
    } else {
        echo "<script>alert('Database Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Contact Us</title>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .contact-section {
            background: url('./images/img/bj_contact.jpg') no-repeat center center;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .contact-form-box {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            width: 50%;
            margin-left: 5%;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
        }

        @media (max-width: 768px) {
            .contact-form-box {
                width: 90%;
                margin: 20px auto;
            }
        }
    </style>
</head>

<body>

    <section class="contact-section">
        <div class="contact-form-box">
            <h3 class="mb-4 text-center">Contact Us</h3>
            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($name); ?>" required readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea name="message" rows="4" class="form-control" required></textarea>
                </div>
                <button type="submit" class="btn btn-success w-100">Submit</button>
            </form>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>