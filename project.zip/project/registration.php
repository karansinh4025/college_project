<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("admin/connection/connect.php");

if (isset($_POST['submit'])) {
   $username = trim($_POST['username']);
   $email = trim($_POST['email']);
   $phone = trim($_POST['phone']);
   $password = $_POST['password'];
   $cpassword = $_POST['cpassword'];
   $address = trim($_POST['address']);

   if (empty($username) || empty($email) || empty($phone) || empty($password) || empty($cpassword) || empty($address)) {
      $message = "All fields are required!";
   } elseif ($password !== $cpassword) {
      $message = "Passwords do not match!";
   } elseif (strlen($password) < 6) {
      $message = "Password must be at least 6 characters!";
   } elseif (strlen($phone) < 10) {
      $message = "Invalid phone number!";
   } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $message = "Invalid email address!";
   } elseif (mysqli_num_rows(mysqli_query($db, "SELECT username FROM users WHERE username = '$username'")) > 0) {
      $message = "Username already exists!";
   } elseif (mysqli_num_rows(mysqli_query($db, "SELECT email FROM users WHERE email = '$email'")) > 0) {
      $message = "Email already exists!";
   } else {
      $hashed_password = md5($password);
      $sql = "INSERT INTO users (username, email, phone, password, address) VALUES ('$username', '$email', '$phone', '$hashed_password', '$address')";
      $result = mysqli_query($db, $sql);

      if ($result) {
         echo "<script>alert('Registration successful! Redirecting to login...');</script>";
         echo "<script>window.location.href='login.php';</script>";
         exit();
      } else {
         $message = "Registration failed. Please try again.";
      }
   }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <title>Register</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link href="css/font-awesome.min.css" rel="stylesheet">
   <link href="css/animsition.min.css" rel="stylesheet">
   <link href="css/animate.css" rel="stylesheet">
   <link href="css/style.css" rel="stylesheet">
   <link rel="stylesheet" href="css/login.css">
</head>

<body>
   <header id="header" class="header-scroll top-header headrom">
      <nav class="navbar navbar-dark">
         <div class="container">
            <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
            <a class="navbar-brand" href="index.php">
               <h2 style="color: white; font-weight: 700; position: relative;right: 63px;">Quick Bite</h2>
            </a>
            <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
               <ul class="nav navbar-nav">
                  <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
                  <li class="nav-item"> <a class="nav-link active" href="restaurants.php">Restaurants</a> </li>
                  <?php
                  if (empty($_SESSION["user_id"])) {
                     echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a></li>
                                  <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a></li>';
                  } else {
                     echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Orders</a></li>';
                     echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a></li>';
                  }
                  ?>
               </ul>
            </div>
         </div>
      </nav>
   </header>

   <div class="login-wrapper">
      <div class="login-image-section ">
         <div class="welcome-text text-center text-white px-4">
            <h1 style="font-size: 3.5rem; font-weight: 700;"><span id="typewriter-text"></span> </h1>
         </div>
      </div>

      <div class="login-form-section">
         <div class="login-form-container">
            <h2>Create your account</h2>

            <?php if (!empty($message)) : ?>
               <p class="error-message" style="color:red;"><?php echo $message; ?></p>
            <?php endif; ?>

            <form action="" method="post">
               <input type="text" name="username" placeholder="Username" required>
               <input type="email" name="email" placeholder="Email" required>
               <input type="tel" name="phone" placeholder="Phone Number" required>
               <input type="password" name="password" placeholder="Password" required>
               <input type="password" name="cpassword" placeholder="Confirm Password" required>
               <textarea name="address" placeholder="Delivery Address" rows="1" required></textarea>
               <input type="submit" name="submit" value="Register" id="buttn">
            </form>

            <div class="button-group">
               <a href="login.php" class="custom-btn">
                  <i class="fa fa-sign-in-alt"></i> Login
               </a>
            </div>
         </div>
      </div>
   </div>

   <footer class="footer">
      <div class="container">
         <div class="bottom-footer">
            <div class="row">
               <div class="col-xs-12 col-sm-3 payment-options color-gray">
                  <h5>Payment Options</h5>
                  <ul>
                     <li><a href="#"> <img src="images/paypal.png" alt="Paypal"> </a></li>
                     <li><a href="#"> <img src="images/mastercard.png" alt="Mastercard"> </a></li>
                     <li><a href="#"> <img src="images/maestro.png" alt="Maestro"> </a></li>
                     <li><a href="#"> <img src="images/stripe.png" alt="Stripe"> </a></li>
                     <li><a href="#"> <img src="images/bitcoin.png" alt="Bitcoin"> </a></li>
                  </ul>
               </div>
               <div class="col-xs-12 col-sm-4 address color-gray">
                  <h5>Address</h5>
                  <p>1086 Stockert Hollow Road, Seattle</p>
                  <h5>Phone: 75696969855</h5>
               </div>
               <div class="col-xs-12 col-sm-5 additional-info color-gray">
                  <h5>Additional Information</h5>
                  <p>Join thousands of other restaurants who benefit from having partnered with us.</p>
               </div>
            </div>
         </div>
      </div>
   </footer>

   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <!-- Typed.js CDN -->
   <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>

   <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
   <script>
      var typed = new Typed("#typewriter-text", {
         strings: [
            "Welcome to",
            "<span style='color:white;'>QUICK BITE RESTAURANT</span>",
            "Enjoy delicious",
            "<span style='color:white;'>delivered fast and fresh!</span>"
         ],

         typeSpeed: 50,
         backSpeed: 25,
         backDelay: 1000,
         smartBackspace: false,
         loop: true,
         showCursor: true
      });
   </script>

</body>

</html>